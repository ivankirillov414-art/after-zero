extends SceneTree

# Prepared integration test. Not run in the environment that assembled A1.1.
# godot --headless --path . --script res://tests/smoke_test.gd
var failures := 0

func _initialize() -> void:
	call_deferred("_run")

func _check(condition: bool, label: String) -> void:
	if condition:
		print("PASS: " + label)
	else:
		failures += 1
		push_error("FAIL: " + label)

func _collect(world, actor, item_id: String) -> void:
	for child in world.get_children():
		if child.get_script() == load("res://scripts/pickup.gd") and child.item_id == item_id:
			child.interact(actor)
			return
	_check(false, "pickup exists: " + item_id)

func _run() -> void:
	var packed = load("res://scenes/main.tscn")
	if packed == null:
		push_error("Cannot load main scene")
		quit(1)
		return
	var world = packed.instantiate()
	root.add_child(world)
	await process_frame
	var actor = world.player
	actor.set_physics_process(false)
	var generator = world.generator
	var terminal = world.get_node("ArchiveTerminal")
	var note = world.get_node("Note_workshop_notice")

	_check(str(world.story_data.get("id", "")) == "green_limit", "selected story")
	_check(not generator.is_on and not generator.repaired, "generator starts broken/off")
	_check(world.journal_entries.has("arrival"), "arrival note unlocked")
	terminal.interact(actor)
	_check(not world.journal_entries.has("terminal_log"), "archive locked without power")
	note.interact(actor)
	_check(actor.journal_visible and not actor.inventory_visible, "reading opens journal only")
	_check(not actor._gameplay_input_enabled(), "movement blocked while reading")
	var count: int = world.journal_entries.size()
	note.interact(actor)
	_check(world.journal_entries.size() == count, "rereading does not duplicate notes")
	actor.journal_visible = false
	actor._sync_mouse_mode()

	_collect(world, actor, "fuel")
	generator.interact(actor)
	_check(not generator.repaired and actor.inventory.has("fuel"), "incomplete repair consumes nothing")
	_collect(world, actor, "spark_plug")
	_collect(world, actor, "carburetor")
	generator.interact(actor)
	_check(generator.repaired and not generator.is_on, "repair does not auto-start")
	_check(not actor.inventory.has("fuel") and not actor.inventory.has("spark_plug") and not actor.inventory.has("carburetor"), "repair consumes exact components")
	generator.interact(actor)
	_check(generator.is_on and terminal.is_powered(), "terminal powered by generator")
	for light in world.shelter_lights:
		_check(light.visible, "shelter light switched on")
	terminal.interact(actor)
	_check(world.journal_entries.has("terminal_log"), "archive unlocks after power")
	_check(world.objective_label.text.contains("ПРОЛОГ ЗАВЕРШЁН"), "prologue can finish")
	generator.interact(actor)
	_check(not terminal.is_powered() and not world.terminal_screen.visible, "switch-off disables terminal")
	_check(world.journal_entries.has("terminal_log"), "already read archive remains in journal")

	var tab_ok := false
	for event in InputMap.action_get_events("inventory"):
		if event is InputEventKey and event.physical_keycode == KEY_TAB:
			tab_ok = true
	_check(tab_ok, "Tab binding")
	var ctrl_ok := false
	for event in InputMap.action_get_events("crouch"):
		if event is InputEventKey and event.physical_keycode == KEY_CTRL:
			ctrl_ok = true
	_check(ctrl_ok, "Ctrl binding")
	world.queue_free()
	await process_frame
	print("FAILURES: ", failures)
	quit(1 if failures > 0 else 0)
