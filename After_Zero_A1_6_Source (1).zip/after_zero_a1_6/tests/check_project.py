"""Static source checks only: NOT a Godot parser or a runtime test."""
from __future__ import annotations
import json
import re
from collections import deque
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = 0

def check(condition: bool, message: str) -> None:
    global checks
    if not condition:
        raise AssertionError(message)
    checks += 1
    print(f"PASS: {message}")

def balanced(text: str) -> bool:
    stack: list[str] = []
    quote = None
    escape = False
    comment = False
    pairs = {')': '(', ']': '[', '}': '{'}
    for char in text:
        if comment:
            if char == '\n':
                comment = False
            continue
        if quote:
            if escape:
                escape = False
            elif char == '\\':
                escape = True
            elif char == quote:
                quote = None
            continue
        if char == '#':
            comment = True
        elif char in "\"'":
            quote = char
        elif char in '([{':
            stack.append(char)
        elif char in ')]}':
            if not stack or stack.pop() != pairs[char]:
                return False
    return not stack and quote is None

config = (ROOT/'project.godot').read_text(encoding='utf-8')
check('config/version="0.1.6"' in config, 'version 0.1.6')
check('"physical_keycode":4194306' in config, 'Tab physical key present')
check('"physical_keycode":4194326' in config, 'Ctrl physical key present')
check('journal={' in config, 'journal input action exists')
for path in sorted(ROOT.rglob('*')):
    if not path.is_file() or path.suffix not in {'.gd','.tscn','.godot'}:
        continue
    text = path.read_text(encoding='utf-8')
    for ref in re.findall(r'res://([^"\s]+)',text):
        check((ROOT/ref).exists(), f'{path.name}: resource {ref}')
    if path.suffix == '.gd':
        check(balanced(text), f'{path.name}: lexical delimiter balance (not compilation)')
        functions = re.findall(r'^func\s+(\w+)\(', text, re.M)
        check(len(functions)==len(set(functions)), f'{path.name}: unique function names')

story=json.loads((ROOT/'data/green_limit_ru.json').read_text(encoding='utf-8'))
check(story['selected_option']==6 and story['id']=='green_limit', 'selected narrative matches option 6')
for note in ['arrival','workshop_notice','field_note','terminal_log','lab_first_log','greenhouse_log','zero_sample']:
    check(bool(story['notes'][note]['title']) and bool(story['notes'][note]['body']), f'complete story note: {note}')

world=(ROOT/'scripts/world.gd').read_text(encoding='utf-8')
player=(ROOT/'scripts/player.gd').read_text(encoding='utf-8')
check('not inventory_visible and not journal_visible' in player, 'gameplay input checks both menus')
check('interact_ray.add_exception(self)' in player, 'interaction excludes player')
check('signal note_found' in player and 'player.note_found.connect' in world, 'note signal is connected')
check('generator.repair_completed.connect(_update_objective)' in world, 'repair updates objective')
check('player.message_requested.connect' in world, 'original message signal preserved')
check('_build_city_block()' in world and '_spawn_loot()' in world, 'original world building preserved')

# Approximate accessibility checks against explicitly declared AABBs. This is
# not Godot physics and does not validate mesh rendering or raycasts.
v=r'Vector3\(([-\d., ]+)\)'
boxes=[]
for m in re.finditer(r'_create_(?:box_static|interactable_box)\("([^"]+)", '+v+r', '+v,world):
    pos=tuple(map(float,m[2].split(',')))
    size=tuple(map(float,m[3].split(',')))
    boxes.append((m[1],pos,size))
boxes.extend([
 ('car1',(-2.8,.55,-15),(1.9,1.1,4.2)),
 ('car2',(3.2,.55,15),(2,1.1,4.4)),
 ('car3',(-1.8,.55,29),(1.8,1.1,4)),
])
loot={}
for m in re.finditer(r'_create_pickup\('+v+r', "([^"]+)"',world):
    loot[m[2]]=tuple(map(float,m[1].split(',')))
for item in ['fuel','spark_plug','carburetor','water']:
    pos=loot[item]
    overlaps=[]
    for name,center,size in boxes:
        if all(abs(pos[i]-center[i]) < (size[i]/2+.275) for i in range(3)):
            overlaps.append(name)
    check(not overlaps, f'{item}: pickup box outside declared solid bodies {overlaps}')

# Grid reachability at 0.5 m, with 0.38 m player clearance. Treat supported
# floor surfaces and geometry above the character as traversable.
obstacles=[]
for _,center,size in boxes:
    if center[1]+size[1]/2<=.21 or center[1]-size[1]/2>=1.9:
        continue
    obstacles.append((center[0],center[2],size[0]/2+.38,size[2]/2+.38))
# Procedurally created tree trunks have fixed positions.
for x,z in [(-10,-5),(9,-9),(10,20),(-10,29),(32,9),(-34,-3),(8,-30),(-7,36),(34,-27)]:
    obstacles.append((x,z,.275+.38,.275+.38))
def free(node: tuple[int,int]) -> bool:
    x,z=node[0]/2,node[1]/2
    return abs(x)<39 and abs(z)<39 and not any(abs(x-cx)<hx and abs(z-cz)<hz for cx,cz,hx,hz in obstacles)
start=(-44,12)
check(free(start),'spawn has approximate player clearance')
seen={start}; queue=deque([start])
while queue:
    x,z=queue.popleft()
    for node in [(x+1,z),(x-1,z),(x,z+1),(x,z-1)]:
        if node not in seen and free(node):
            seen.add(node); queue.append(node)
for name,pos in loot.items():
    near=any((x/2-pos[0])**2+(z/2-pos[2])**2<1.7**2 for x,z in seen)
    check(near,f'{name}: approximate walkable approach from shelter')


reactive=(ROOT/'scripts/reactive_growth.gd').read_text(encoding='utf-8')
check('REACTIVE_GROWTH_SCRIPT' in world and '_build_reactive_ecosystem()' in world, 'reactive ecosystem is constructed')
check('hostile_pressure' in reactive and 'apply_environment_damage' in reactive, 'reactive growth has hostile pressure response')
check('GREENBELT ECOLOGY LAB' in world and 'PINE RIDGE MARKET' in world, 'Riverdale extension landmarks exist')
check('_update_reactive_ecosystem()' in world, 'ecosystem pressure propagates to growth nodes')

creature=(ROOT/'scripts/creature_threat.gd').read_text(encoding='utf-8')
labdoor=(ROOT/'scripts/lab_door.gd').read_text(encoding='utf-8')
check('get_noise_level' in player and 'current_noise' in player, 'player exposes movement noise')
check('CREATURE_THREAT_SCRIPT' in world and 'RootStalker_01' in world, 'first mobile threat is spawned')
check('hearing_radius' in creature and 'get_noise_level' in creature, 'threat reacts to player noise')
check('LAB_DOOR_SCRIPT' in world and 'LabEntry' in world and 'LabExit' in world, 'playable lab entry and exit exist')
check('requires_crowbar' in labdoor and 'terminal_log' in labdoor, 'lab entry is gated by archive and crowbar')
check('lab_entered' in world and '"lab_entered":lab_entered' in world, 'lab progress is saved')

noise=(ROOT/'scripts/noise_decoy.gd').read_text(encoding='utf-8')
check('GreenhouseBFloor' in world and 'GREENHOUSE B' in world, 'greenhouse B prototype exists')
check('RootStalker_Lab' in world, 'second lab stalker exists')
check('emit_noise_at' in world and 'hear_noise' in creature and 'NOISE_DECOY_SCRIPT' in world, 'noise lure can redirect threats')
check('stealth_label' in world and 'get_noise_level' in world, 'stealth noise HUD exists')
check('signal died' in player and 'respawn_at' in player and '_on_player_died' in world, 'death and shelter respawn loop exists')
check('sample_zero' in world and 'greenhouse_sample_found' in world, 'ZERO sample progression exists')

print(f'\n{checks} static checks passed.')
print('NOT RUN: Godot import/compilation, smoke_test.gd, rendering, manual gameplay.')
