extends StaticBody3D

@export var item_id := "scrap"
@export var display_name := "Металлолом"
@export var amount := 1

func get_interaction_text() -> String:
	return "[E] Взять: %s x%d" % [display_name, amount]

func interact(actor) -> void:
	if actor and actor.has_method("add_item"):
		actor.add_item(item_id, display_name, amount)
		queue_free()
