extends StaticBody3D

@export var display_name := "Ящик"
@export var loot: Array[Dictionary] = []
var searched := false

func get_interaction_text() -> String:
	if searched:
		return "%s — пусто" % display_name
	return "[E] Обыскать: %s" % display_name

func interact(actor) -> void:
	if searched:
		return
	searched = true
	if loot.is_empty():
		actor.message_requested.emit("%s: ничего полезного" % display_name)
		return
	for entry in loot:
		actor.add_item(str(entry.get("id", "scrap")), str(entry.get("name", "Предмет")), int(entry.get("amount", 1)))
