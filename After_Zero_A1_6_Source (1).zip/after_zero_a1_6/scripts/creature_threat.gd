extends CharacterBody3D

@export var patrol_radius := 7.0
@export var hearing_radius := 16.0
@export var chase_speed := 3.3
@export var investigate_speed := 2.0
@export var damage := 10.0
@export var attack_distance := 1.45
@export var attack_cooldown := 1.4
var player: Node3D
var home := Vector3.ZERO
var target := Vector3.ZERO
var attack_timer := 0.0
var alert := 0.0
var body_mesh: MeshInstance3D

func _ready() -> void:
 home = global_position
 target = home
 body_mesh = _make_body()

func set_player(value: Node3D) -> void:
 player = value

func _physics_process(delta: float) -> void:
 if not is_instance_valid(player): return
 attack_timer = maxf(0.0, attack_timer-delta)
 var dist := global_position.distance_to(player.global_position)
 var noise := float(player.get_noise_level()) if player.has_method("get_noise_level") else 0.0
 var heard := dist <= hearing_radius * maxf(0.15, noise)
 if heard:
  target = player.global_position
  alert = 4.0
 else:
  alert = maxf(0.0, alert-delta)
  if global_position.distance_to(target) < 1.0:
   var t := Time.get_ticks_msec()/1000.0
   target = home + Vector3(sin(t*0.63)*patrol_radius,0,cos(t*0.47)*patrol_radius)
 var speed := chase_speed if alert > 0.0 else investigate_speed
 var flat := target-global_position; flat.y=0
 if flat.length() > 0.35:
  var dir := flat.normalized(); velocity.x=dir.x*speed; velocity.z=dir.z*speed
  look_at(global_position+Vector3(dir.x,0,dir.z),Vector3.UP)
 else:
  velocity.x=move_toward(velocity.x,0.0,speed*delta*4.0); velocity.z=move_toward(velocity.z,0.0,speed*delta*4.0)
 if not is_on_floor(): velocity.y -= 9.8*delta
 move_and_slide()
 if dist <= attack_distance and attack_timer <= 0.0 and player.has_method("apply_environment_damage"):
  player.apply_environment_damage(damage,"Что-то из зарослей ударило тебя. Беги или двигайся тише.")
  attack_timer=attack_cooldown
 if body_mesh:
  body_mesh.modulate = Color(1.15,0.65,0.45) if alert>0.0 else Color.WHITE

func _make_body() -> MeshInstance3D:
 var shape:=CapsuleShape3D.new(); shape.radius=0.48; shape.height=1.55
 var col:=CollisionShape3D.new(); col.shape=shape; add_child(col)
 var mesh:=CapsuleMesh.new(); mesh.radius=0.48; mesh.height=1.55
 var inst:=MeshInstance3D.new(); inst.mesh=mesh; inst.position.y=0.78
 var mat:=StandardMaterial3D.new(); mat.albedo_color=Color(0.22,0.32,0.14); mat.roughness=1.0; inst.material_override=mat
 add_child(inst)
 return inst


func hear_noise(pos: Vector3, strength: float = 1.0) -> void:
 var max_distance := hearing_radius * maxf(0.25, strength)
 if global_position.distance_to(pos) <= max_distance:
  target = pos
  alert = maxf(alert, 5.0 * strength)
