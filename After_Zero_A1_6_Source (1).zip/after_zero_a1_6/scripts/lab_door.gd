extends StaticBody3D
@export var display_name := "Вход в Greenbelt Ecology Lab"
@export var destination := Vector3.ZERO
@export var requires_crowbar := true
@export var requires_archive := true
var world: Node = null
func get_interaction_text() -> String: return "[E] " + display_name
func interact(actor) -> void:
 if requires_archive and world and not world.has_story_entry("terminal_log"):
  actor.message_requested.emit("Сначала стоит изучить архив мастерской."); return
 if requires_crowbar and not actor.has_item("crowbar"):
  actor.message_requested.emit("Дверь заклинило. Нужна монтировка."); return
 actor.global_position = destination
 actor.message_requested.emit("Ты проходишь внутрь исследовательского корпуса.")
 if world and world.has_method("on_lab_entered"): world.on_lab_entered()
