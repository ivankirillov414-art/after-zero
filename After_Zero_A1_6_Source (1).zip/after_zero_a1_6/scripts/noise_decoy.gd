extends StaticBody3D
@export var display_name := "Аварийный зуммер"
var world: Node
var cooldown := 0.0
func _process(delta: float) -> void: cooldown=maxf(0.0,cooldown-delta)
func get_interaction_text() -> String: return "[E] Включить %s" % display_name if cooldown<=0.0 else "Зуммер перезаряжается"
func interact(_player: Node) -> void:
 if cooldown>0.0: return
 cooldown=8.0
 if world and world.has_method("emit_noise_at"): world.emit_noise_at(global_position,1.35)
 if world and world.has_method("_on_message_requested"): world._on_message_requested("Зуммер орёт несколько секунд. Что-то в корнях меняет направление.")
