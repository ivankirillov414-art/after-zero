extends StaticBody3D

@export var display_name := "Разбираемый объект"
@export var required_tool := "crowbar"
@export var required_tool_name := "монтировка"
@export var salvage: Array[Dictionary] = []
var dismantled := false

func get_interaction_text() -> String:
	if dismantled:
		return "%s — разобрано" % display_name
	return "[E] Разобрать: %s" % display_name

func interact(actor) -> void:
	if dismantled:
		return
	if required_tool != "" and not actor.has_item(required_tool):
		actor.message_requested.emit("Нужен инструмент: %s" % required_tool_name)
		return
	dismantled = true
	for entry in salvage:
		actor.add_item(str(entry.get("id", "scrap")), str(entry.get("name", "Материал")), int(entry.get("amount", 1)))
	actor.message_requested.emit("%s разобрано" % display_name)
