extends StaticBody3D

@export var display_name := "Верстак"

func get_interaction_text() -> String:
	return "[E] Использовать верстак"

func interact(actor) -> void:
	if actor and actor.has_method("toggle_crafting"):
		actor.toggle_crafting()
