extends Area3D
@export var damage_per_second := 4.0
@export var warning_text := "Воздух насыщен спорами. Покиньте заражённую зону."
var occupants: Array[Node] = []
func _ready() -> void:
 body_entered.connect(_entered); body_exited.connect(_exited)
func _physics_process(delta: float) -> void:
 for body in occupants.duplicate():
  if not is_instance_valid(body): occupants.erase(body)
  elif body.has_method("apply_environment_damage"): body.apply_environment_damage(damage_per_second * delta * (0.25 if body.has_item("respirator") else 1.0), warning_text if not body.has_item("respirator") else "Респиратор задерживает большую часть спор.")
func _entered(body: Node) -> void:
 if body.has_method("apply_environment_damage"):
  occupants.append(body); body.message_requested.emit(warning_text)
func _exited(body: Node) -> void:
 occupants.erase(body)
