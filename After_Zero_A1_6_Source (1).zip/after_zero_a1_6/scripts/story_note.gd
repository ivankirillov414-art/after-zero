extends StaticBody3D

@export var note_id := ""
@export var display_name := "Записка"
@export var note_title := "Наблюдение"
@export_multiline var note_body := ""
var was_read := false

func get_interaction_text() -> String:
	return "[E] %s: %s" % ["Перечитать" if was_read else "Прочитать", display_name]

func interact(actor) -> void:
	if actor and actor.has_method("read_note"):
		was_read = true
		actor.read_note(note_id, note_title, note_body)
