extends StaticBody3D

@export var note_id := "terminal_log"
@export var note_title := "Полевой журнал"
@export_multiline var note_body := ""
var power_source = null

func is_powered() -> bool:
	return is_instance_valid(power_source) and bool(power_source.is_on)

func get_interaction_text() -> String:
	return "[E] Прочитать архив терминала" if is_powered() else "[E] Терминал: нет питания"

func interact(actor) -> void:
	if not actor:
		return
	if not is_powered():
		actor.message_requested.emit("Сначала восстанови и запусти генератор в мастерской.")
		return
	if actor.has_method("read_note"):
		actor.read_note(note_id, note_title, note_body)
