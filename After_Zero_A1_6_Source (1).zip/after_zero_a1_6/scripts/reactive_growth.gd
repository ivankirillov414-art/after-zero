extends Node3D

@export var activation_pressure := 8.0
@export var hostile_pressure := 20.0
@export var damage_per_second := 2.0
@export var display_name := "Реактивная колония"
var pressure := 0.0
var player: Node = null
var pulse := 0.0
var core: MeshInstance3D
var tendrils: Array[MeshInstance3D] = []

func _ready() -> void:
 core = _make_sphere(Vector3(0,0.45,0), Vector3(1.0,0.65,1.0), Color(0.25,0.34,0.12))
 for i in range(6):
  var a := TAU * float(i) / 6.0
  var t := _make_box(Vector3(cos(a)*1.15,0.18,sin(a)*1.15), Vector3(1.5,0.12,0.18), Color(0.19,0.30,0.10))
  t.rotation.y = -a
  tendrils.append(t)
 set_pressure(pressure)

func _physics_process(delta: float) -> void:
 pulse += delta
 if core and pressure >= activation_pressure:
  var s := 1.0 + sin(pulse*2.4)*0.08
  core.scale = Vector3(s,s,s)
 if pressure >= hostile_pressure and is_instance_valid(player):
  if global_position.distance_to(player.global_position) < 3.0 and player.has_method("apply_environment_damage"):
   player.apply_environment_damage(damage_per_second*delta, "Колючая колония реагирует на движение. Отойди от неё.")

func set_player(value: Node) -> void:
 player = value

func set_pressure(value: float) -> void:
 pressure = value
 if not core: return
 var active := pressure >= activation_pressure
 var hostile := pressure >= hostile_pressure
 core.visible = true
 core.modulate = Color(1.15,0.75,0.55) if hostile else (Color(0.95,1.08,0.72) if active else Color.WHITE)
 for t in tendrils:
  t.visible = active

func _make_sphere(pos: Vector3, scale_value: Vector3, color: Color) -> MeshInstance3D:
 var mesh := SphereMesh.new(); mesh.radius=0.5; mesh.height=1.0; mesh.radial_segments=10; mesh.rings=6
 var inst := MeshInstance3D.new(); inst.mesh=mesh; inst.position=pos; inst.scale=scale_value
 var mat := StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=1.0; inst.material_override=mat
 add_child(inst); return inst

func _make_box(pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
 var mesh := BoxMesh.new(); mesh.size=size
 var inst := MeshInstance3D.new(); inst.mesh=mesh; inst.position=pos
 var mat := StandardMaterial3D.new(); mat.albedo_color=color; mat.roughness=1.0; inst.material_override=mat
 add_child(inst); return inst
