extends Node3D

const PLAYER_SCENE := preload("res://scenes/player.tscn")
const PICKUP_SCRIPT := preload("res://scripts/pickup.gd")
const CONTAINER_SCRIPT := preload("res://scripts/container_interactable.gd")
const GENERATOR_SCRIPT := preload("res://scripts/generator_interactable.gd")
const NOTE_SCRIPT := preload("res://scripts/story_note.gd")
const TERMINAL_SCRIPT := preload("res://scripts/archive_terminal.gd")
const STORY_PATH := "res://data/green_limit_ru.json"
const SPORE_ZONE_SCRIPT := preload("res://scripts/spore_zone.gd")
const SALVAGE_SCRIPT := preload("res://scripts/salvage_interactable.gd")
const WORKBENCH_SCRIPT := preload("res://scripts/workbench_interactable.gd")
const REACTIVE_GROWTH_SCRIPT := preload("res://scripts/reactive_growth.gd")
const CREATURE_THREAT_SCRIPT := preload("res://scripts/creature_threat.gd")
const LAB_DOOR_SCRIPT := preload("res://scripts/lab_door.gd")
const NOISE_DECOY_SCRIPT := preload("res://scripts/noise_decoy.gd")
const SAVE_PATH := "user://after_zero_a1_6_save.json"

var player
var hud: CanvasLayer
var stats_label: Label
var prompt_label: Label
var message_label: Label
var inventory_panel: PanelContainer
var inventory_label: Label
var shelter_lights: Array[OmniLight3D] = []
var message_timer := 0.0
var generator = null
var story_data: Dictionary = {}
var journal_entries: Dictionary = {}
var journal_order: Array[String] = []
var journal_panel: PanelContainer
var journal_text: RichTextLabel
var objective_label: Label
var terminal_screen: MeshInstance3D
var crafting_panel: PanelContainer
var crafting_text: RichTextLabel
var ecosystem_pressure := 0.0
var ecosystem_label: Label
var reactive_growths: Array[Node3D] = []
var lab_entered := false
var living_threats: Array[Node3D] = []
var stealth_label: Label
var greenhouse_sample_found := false

func _ready() -> void:
	_load_story()
	_build_environment()
	_build_city_block()
	_build_shelter()
	_spawn_player()
	_build_hud()
	_spawn_loot()
	_build_overgrowth()
	_build_story_objects()
	_build_spore_zones()
	_build_salvage_loop()
	_build_riverdale_extension()
	_build_reactive_ecosystem()
	_build_a15_threat_and_lab()
	_build_a16_lab_extension()
	_add_story_entry("arrival")
	_update_objective()

func _process(delta: float) -> void:
	if message_timer > 0.0:
		message_timer -= delta
		if message_timer <= 0.0 and message_label:
			message_label.text = ""
	if player and inventory_panel:
		inventory_panel.visible = player.inventory_visible
	if player and journal_panel:
		journal_panel.visible = player.journal_visible
	if player and crafting_panel:
		crafting_panel.visible = player.crafting_visible
	if player and stealth_label:
		var noise := player.get_noise_level()
		var state := "ТИХО" if noise < 0.3 else ("СЛЫШНО" if noise < 0.75 else "ГРОМКО")
		stealth_label.text = "ШУМ: %s  %.2f" % [state, noise]

func _build_environment() -> void:
	var environment := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.36, 0.45, 0.38)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.55, 0.62, 0.51)
	env.ambient_light_energy = 0.62
	env.fog_enabled = true
	env.fog_light_color = Color(0.36, 0.45, 0.38)
	env.fog_density = 0.006
	environment.environment = env
	add_child(environment)

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -28, 0)
	sun.light_energy = 0.75
	sun.light_color = Color(0.96, 0.92, 0.76)
	sun.shadow_enabled = true
	add_child(sun)

func _build_city_block() -> void:
	_create_box_static("Ground", Vector3(0, -0.5, 0), Vector3(80, 1, 80), Color(0.24, 0.28, 0.21))
	_create_box_static("Road", Vector3(0, 0.03, 0), Vector3(14, 0.08, 80), Color(0.08, 0.085, 0.09))
	_create_box_static("CrossRoad", Vector3(0, 0.04, 8), Vector3(80, 0.08, 12), Color(0.08, 0.085, 0.09))

	# Apartment blocks / shop shells — deliberately primitive for A1 graybox.
	_create_box_static("BlockA", Vector3(-20, 5, -18), Vector3(18, 10, 20), Color(0.22, 0.24, 0.25))
	_create_box_static("BlockB", Vector3(20, 7, -20), Vector3(16, 14, 18), Color(0.24, 0.23, 0.22))
	_create_box_static("Store", Vector3(22, 2.2, 22), Vector3(18, 4.4, 12), Color(0.26, 0.27, 0.25))
	_create_box_static("Garages", Vector3(-23, 1.7, 25), Vector3(22, 3.4, 9), Color(0.20, 0.21, 0.22))

	# Road debris and abandoned car silhouettes.
	for data in [
		[Vector3(-2.8, 0.55, -15), Vector3(1.9, 1.1, 4.2)],
		[Vector3(3.2, 0.55, 15), Vector3(2.0, 1.1, 4.4)],
		[Vector3(-1.8, 0.55, 29), Vector3(1.8, 1.1, 4.0)]
	]:
		_create_box_static("AbandonedCar", data[0], data[1], Color(0.16, 0.17, 0.18))

	for pos in [Vector3(-5,0.45,2), Vector3(6,0.3,-5), Vector3(3,0.25,33), Vector3(-8,0.25,-29)]:
		_create_box_static("Debris", pos, Vector3(1.1, 0.5, 0.8), Color(0.24, 0.23, 0.21))

func _build_shelter() -> void:
	# Open-front workshop shelter near spawn.
	_create_box_static("ShelterFloor", Vector3(-22, 0.1, 7), Vector3(10, 0.2, 8), Color(0.25, 0.23, 0.20))
	_create_box_static("ShelterBack", Vector3(-22, 2.5, 10.8), Vector3(10, 5, 0.3), Color(0.22, 0.21, 0.19))
	_create_box_static("ShelterLeft", Vector3(-26.8, 2.5, 7), Vector3(0.3, 5, 8), Color(0.22, 0.21, 0.19))
	_create_box_static("ShelterRight", Vector3(-17.2, 2.5, 7), Vector3(0.3, 5, 8), Color(0.22, 0.21, 0.19))
	_create_box_static("ShelterRoof", Vector3(-22, 5.0, 7), Vector3(10, 0.3, 8), Color(0.18, 0.18, 0.17))

	for x in [-24.5, -19.5]:
		var light := OmniLight3D.new()
		light.position = Vector3(x, 3.7, 7)
		light.omni_range = 8.0
		light.light_energy = 2.0
		light.visible = false
		add_child(light)
		shelter_lights.append(light)

	generator = _create_interactable_box("Generator", Vector3(-25, 0.65, 9.3), Vector3(1.2, 1.3, 1.0), Color(0.27, 0.26, 0.18), GENERATOR_SCRIPT)
	generator.power_state_changed.connect(_on_power_state_changed)
	generator.repair_completed.connect(_update_objective)

func _spawn_player() -> void:
	player = PLAYER_SCENE.instantiate()
	player.position = Vector3(-22, 0.25, 6.2)
	add_child(player)

func _build_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	_build_story_hud()

	stats_label = Label.new()
	stats_label.position = Vector2(20, 57)
	stats_label.add_theme_font_size_override("font_size", 18)
	hud.add_child(stats_label)

	var crosshair := Label.new()
	crosshair.text = "+"
	crosshair.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	crosshair.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.position = Vector2(-10, -14)
	crosshair.size = Vector2(20, 28)
	crosshair.add_theme_font_size_override("font_size", 22)
	hud.add_child(crosshair)

	prompt_label = Label.new()
	prompt_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	prompt_label.position = Vector2(-260, -90)
	prompt_label.size = Vector2(520, 38)
	prompt_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt_label.add_theme_font_size_override("font_size", 20)
	hud.add_child(prompt_label)

	message_label = Label.new()
	message_label.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
	message_label.position = Vector2(-350, -181)
	message_label.size = Vector2(700, 72)
	message_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	message_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	message_label.add_theme_font_size_override("font_size", 18)
	hud.add_child(message_label)

	inventory_panel = PanelContainer.new()
	inventory_panel.set_anchors_preset(Control.PRESET_CENTER)
	inventory_panel.position = Vector2(-270, -230)
	inventory_panel.size = Vector2(540, 460)
	inventory_panel.visible = false
	hud.add_child(inventory_panel)

	var margin := MarginContainer.new()
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_top", 22)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_bottom", 22)
	inventory_panel.add_child(margin)

	inventory_label = Label.new()
	inventory_label.text = "ИНВЕНТАРЬ\n\nПусто\n\n[TAB] закрыть"
	inventory_label.add_theme_font_size_override("font_size", 18)
	inventory_label.custom_minimum_size = Vector2(460, 0)
	inventory_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	margin.add_child(inventory_label)

	crafting_panel = PanelContainer.new()
	crafting_panel.set_anchors_preset(Control.PRESET_CENTER)
	crafting_panel.position = Vector2(-330, -245)
	crafting_panel.size = Vector2(660, 490)
	crafting_panel.visible = false
	hud.add_child(crafting_panel)
	var craft_margin := MarginContainer.new()
	craft_margin.add_theme_constant_override("margin_left", 24)
	craft_margin.add_theme_constant_override("margin_top", 22)
	craft_margin.add_theme_constant_override("margin_right", 24)
	craft_margin.add_theme_constant_override("margin_bottom", 22)
	crafting_panel.add_child(craft_margin)
	crafting_text = RichTextLabel.new()
	crafting_text.bbcode_enabled = true
	crafting_text.text = "[b]ВЕРСТАК / КРАФТ[/b]\n\n[1] Монтировка — металл x2, крепёж x2\n[2] Самодельный респиратор — ткань x2, пластик x1, химикаты x1\n[3] Фильтр для воды — пластик x2, ткань x1, уголь x2\n\nНажми цифровую клавишу, чтобы изготовить. [C] закрыть."
	craft_margin.add_child(crafting_text)

	ecosystem_label = Label.new()
	ecosystem_label.position = Vector2(20, 190)
	ecosystem_label.size = Vector2(560, 48)
	ecosystem_label.add_theme_font_size_override("font_size", 16)
	hud.add_child(ecosystem_label)
	_update_ecosystem_label()

	stealth_label = Label.new()
	stealth_label.position = Vector2(20, 225)
	stealth_label.size = Vector2(560, 40)
	stealth_label.add_theme_font_size_override("font_size", 15)
	hud.add_child(stealth_label)

	var controls := Label.new()
	controls.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	controls.position = Vector2(18, -94)
	controls.size = Vector2(620, 80)
	controls.text = "WASD — движение | Shift — бег | Ctrl — присесть | Space — прыжок\nE — взаимодействие | F — фонарь | 1 вода | 2 еда | 3 аптечка | Tab — вещи | J — журнал | C — крафт"
	controls.add_theme_font_size_override("font_size", 14)
	hud.add_child(controls)

	player.stats_changed.connect(_on_stats_changed)
	player.interaction_changed.connect(_on_interaction_changed)
	player.inventory_changed.connect(_on_inventory_changed)
	player.message_requested.connect(_on_message_requested)
	player.note_found.connect(_on_note_found)
	player.died.connect(_on_player_died)
	_on_stats_changed({"health":100.0,"hunger":100.0,"thirst":100.0,"stamina":100.0})
	_on_inventory_changed({})

func _spawn_loot() -> void:
	_create_pickup(Vector3(20.5, 0.4, 14.8), "fuel", "Канистра топлива", 1, Color(0.45, 0.18, 0.12))
	_create_pickup(Vector3(-21.5, 0.4, 18.9), "spark_plug", "Свеча зажигания", 1, Color(0.72, 0.72, 0.68))
	_create_pickup(Vector3(-4.7, 0.4, -14.3), "carburetor", "Карбюратор", 1, Color(0.32, 0.34, 0.34))
	_create_pickup(Vector3(7.0, 0.45, 5.0), "scrap", "Металлолом", 3, Color(0.34, 0.30, 0.26))
	_create_pickup(Vector3(24.0, 0.4, 14.8), "water", "Бутылка воды", 1, Color(0.18, 0.42, 0.62))
	_create_pickup(Vector3(11.5, 0.4, 24.5), "food", "Консервы", 1, Color(0.45, 0.35, 0.16))
	_create_pickup(Vector3(-11.5, 0.4, 25.0), "medkit", "Аптечка", 1, Color(0.62, 0.18, 0.16))

	var crate = _create_interactable_box("LootCrate", Vector3(-20.0, 0.55, 8.8), Vector3(1.4, 1.1, 1.0), Color(0.30, 0.22, 0.12), CONTAINER_SCRIPT)
	crate.display_name = "Старый инструментальный ящик"
	crate.loot = [
		{"id":"wire", "name":"Медный провод", "amount":2},
		{"id":"bolts", "name":"Крепёж", "amount":4}
	]

func _create_pickup(pos: Vector3, id: String, name: String, amount: int, color: Color) -> void:
	var body = _create_interactable_box(name, pos, Vector3(0.55, 0.55, 0.55), color, PICKUP_SCRIPT)
	body.item_id = id
	body.display_name = name
	body.amount = amount

func _create_box_static(node_name: String, pos: Vector3, size: Vector3, color: Color) -> StaticBody3D:
	return _create_interactable_box(node_name, pos, size, color, null)

func _create_interactable_box(node_name: String, pos: Vector3, size: Vector3, color: Color, script_res) -> StaticBody3D:
	var body := StaticBody3D.new()
	body.name = node_name
	body.position = pos
	body.collision_layer = 1 if script_res == null else 2
	body.collision_mask = 1
	if script_res != null:
		body.set_script(script_res)

	var shape := BoxShape3D.new()
	shape.size = size
	var collision := CollisionShape3D.new()
	collision.shape = shape
	body.add_child(collision)

	var box := BoxMesh.new()
	box.size = size
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 0.9
	box.material = material
	var mesh := MeshInstance3D.new()
	mesh.mesh = box
	body.add_child(mesh)

	add_child(body)
	return body

func _on_stats_changed(stats: Dictionary) -> void:
	if !stats_label:
		return
	stats_label.text = "HP %3d   Голод %3d   Жажда %3d   Выносливость %3d" % [
		int(stats["health"]), int(stats["hunger"]), int(stats["thirst"]), int(stats["stamina"])
	]

func _on_interaction_changed(text: String) -> void:
	if prompt_label:
		prompt_label.text = text

func _on_inventory_changed(items: Dictionary) -> void:
	_update_objective()
	if !inventory_label:
		return
	var lines: Array[String] = ["ИНВЕНТАРЬ", ""]
	if items.is_empty():
		lines.append("Пусто")
	else:
		for key in items.keys():
			lines.append("• %s x%d" % [items[key]["name"], int(items[key]["amount"])])
	lines.append("")
	lines.append("Цель пролога: вернуть питание мастерской и прочитать архив терминала. Подсказки о деталях — в журнале [J].")
	lines.append("")
	lines.append("[TAB] закрыть")
	inventory_label.text = "\n".join(lines)

func _on_message_requested(text: String) -> void:
	message_label.text = text
	message_timer = 4.5

func _on_power_state_changed(is_on: bool) -> void:
	for light in shelter_lights:
		light.visible = is_on
	if terminal_screen:
		terminal_screen.visible = is_on
	_update_objective()

# A1.1: story integration. The overgrowth below is static scenery, not an ecosystem simulation.
func _load_story() -> void:
	if not FileAccess.file_exists(STORY_PATH):
		push_error("Missing story resource: " + STORY_PATH)
		return
	var decoded = JSON.parse_string(FileAccess.get_file_as_string(STORY_PATH))
	if decoded is Dictionary:
		story_data = decoded
	else:
		push_error("Invalid story JSON: " + STORY_PATH)

func _build_story_hud() -> void:
	var title := Label.new()
	title.text = "ПОСЛЕ НУЛЯ  /  ЗЕЛЁНЫЙ ПРЕДЕЛ  /  A1.5"
	title.position = Vector2(20, 18)
	title.add_theme_font_size_override("font_size", 21)
	hud.add_child(title)
	objective_label = Label.new()
	objective_label.position = Vector2(20, 94)
	objective_label.size = Vector2(570, 92)
	objective_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	objective_label.add_theme_font_size_override("font_size", 18)
	hud.add_child(objective_label)

	journal_panel = PanelContainer.new()
	journal_panel.set_anchors_preset(Control.PRESET_CENTER)
	journal_panel.position = Vector2(-430, -268)
	journal_panel.size = Vector2(860, 536)
	journal_panel.visible = false
	journal_panel.z_index = 20
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.065, 0.052, 0.98)
	style.set_border_width_all(2)
	style.border_color = Color(0.37, 0.51, 0.32)
	journal_panel.add_theme_stylebox_override("panel", style)
	hud.add_child(journal_panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 24)
	journal_panel.add_child(margin)
	journal_text = RichTextLabel.new()
	journal_text.bbcode_enabled = true
	journal_text.scroll_active = true
	journal_text.add_theme_font_size_override("normal_font_size", 19)
	journal_text.add_theme_font_size_override("bold_font_size", 21)
	margin.add_child(journal_text)

func _build_story_objects() -> void:
	var workbench = _create_interactable_box("Workbench", Vector3(-23.2, 0.55, 8.5), Vector3(1.8, 1.1, 0.95), Color(0.28, 0.25, 0.19), WORKBENCH_SCRIPT)
	_create_note(Vector3(-23.2, 1.16, 8.35), "workshop_notice", "Записка на верстаке")
	_create_note(Vector3(-24.0, 0.28, 18.9), "field_note", "Полевой блокнот")
	var terminal = _create_interactable_box("ArchiveTerminal", Vector3(-18.7, 1.0, 9.3), Vector3(0.9, 1.5, 0.65), Color(0.18, 0.22, 0.19), TERMINAL_SCRIPT)
	terminal.power_source = generator
	var entry: Dictionary = story_data.get("notes", {}).get("terminal_log", {})
	terminal.note_title = str(entry.get("title", "Архив"))
	terminal.note_body = str(entry.get("body", ""))
	terminal_screen = _visual_box(Vector3(-18.7, 1.3, 8.955), Vector3(0.66, 0.5, 0.035), Color(0.35, 0.68, 0.4))
	terminal_screen.visible = false
	_sign(Vector3(-22, 4.2, 2.93), "МАСТЕРСКАЯ", 60)
	_sign(Vector3(-23, 2.4, 20.4), "ГАРАЖИ", 55)
	_sign(Vector3(22, 3.3, 15.9), "МАГАЗИН", 60)

func _create_note(pos: Vector3, note_id: String, display_name: String) -> void:
	var note = _create_interactable_box("Note_" + note_id, pos, Vector3(0.46, 0.08, 0.34), Color(0.86, 0.8, 0.58), NOTE_SCRIPT)
	var entry: Dictionary = story_data.get("notes", {}).get(note_id, {})
	note.note_id = note_id
	note.display_name = display_name
	note.note_title = str(entry.get("title", display_name))
	note.note_body = str(entry.get("body", ""))

func _add_story_entry(note_id: String) -> void:
	var entry: Dictionary = story_data.get("notes", {}).get(note_id, {})
	if not entry.is_empty():
		_on_note_found(note_id, str(entry.get("title", "Запись")), str(entry.get("body", "")))

func _on_note_found(note_id: String, title: String, body: String) -> void:
	if journal_entries.has(note_id):
		journal_order.erase(note_id)
	journal_order.append(note_id)
	journal_entries[note_id] = {"title": title, "body": body}
	var lines: Array[String] = ["[b]ПОЛЕВОЙ ЖУРНАЛ[/b]  —  [J] или [Esc] закрыть", ""]
	# Most recently read entries first; rereading never duplicates them.
	for i in range(journal_order.size() - 1, -1, -1):
		var entry: Dictionary = journal_entries[journal_order[i]]
		lines.append("[b]" + str(entry["title"]) + "[/b]")
		lines.append(str(entry["body"]))
		lines.append("")
	journal_text.text = "\n".join(lines)
	journal_text.scroll_to_line(0)
	_update_objective()

func _update_objective() -> void:
	if not objective_label or not player or not is_instance_valid(generator):
		return
	var text := ""
	if journal_entries.has("lab_first_log"):
		text = "A1.5: найден журнал Greenbelt. Исследуй квартал и подготовься к следующей вылазке."
	elif journal_entries.has("terminal_log"):
		text = "Архив указывает на Greenbelt Ecology Lab. Сделай монтировку [C] и проникни в научный корпус."
	elif not journal_entries.has("workshop_notice"):
		text = "Осмотри записку на верстаке в мастерской [E]."
	elif not generator.repaired:
		var names := {"fuel": "топливо", "spark_plug": "свеча", "carburetor": "карбюратор"}
		var missing: Array[String] = []
		for key in names:
			if not player.inventory.has(key):
				missing.append(names[key])
		text = "Найди: " + ", ".join(missing) + ". Подсказки: журнал [J]." if not missing.is_empty() else "Детали собраны. Вернись к генератору и отремонтируй его [E]."
	elif not generator.is_on:
		text = "Генератор исправен. Запусти его [E]."
	else:
		text = "Питание восстановлено. Прочитай архив на терминале в мастерской [E]."
	objective_label.text = "ТЕКУЩАЯ ЗАДАЧА\n" + text

func _sign(pos: Vector3, text: String, font_size: int) -> void:
	var label := Label3D.new()
	label.position = pos
	label.rotation.y = PI
	label.text = text
	label.font_size = font_size
	label.outline_size = 8
	label.pixel_size = 0.012
	label.modulate = Color(0.81, 0.78, 0.59)
	add_child(label)

func _visual_box(pos: Vector3, size: Vector3, color: Color) -> MeshInstance3D:
	var box := BoxMesh.new()
	box.size = size
	var instance := MeshInstance3D.new()
	instance.mesh = box
	instance.position = pos
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 1.0
	instance.material_override = material
	add_child(instance)
	return instance

func _foliage_blob(pos: Vector3, size: Vector3, color: Color) -> void:
	var sphere := SphereMesh.new()
	sphere.radius = 0.5
	sphere.height = 1.0
	sphere.radial_segments = 8
	sphere.rings = 4
	var instance := MeshInstance3D.new()
	instance.mesh = sphere
	instance.position = pos
	instance.scale = size
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.roughness = 1.0
	instance.material_override = material
	add_child(instance)

func _build_overgrowth() -> void:
	# Deliberate clear area around the shelter; not affected by generator power.
	var rng := RandomNumberGenerator.new()
	rng.seed = 60417
	for pos in [Vector3(-10, 0, -5), Vector3(9, 0, -9), Vector3(10, 0, 20), Vector3(-10, 0, 29), Vector3(32, 0, 9), Vector3(-34, 0, -3), Vector3(8, 0, -30), Vector3(-7, 0, 36), Vector3(34, 0, -27)]:
		var height := rng.randf_range(5.0, 8.0)
		_create_box_static("TreeTrunk", pos + Vector3(0, height * 0.45, 0), Vector3(0.55, height * 0.9, 0.55), Color(0.22, 0.18, 0.12))
		_foliage_blob(pos + Vector3(0, height, 0), Vector3(5.0, 4.2, 5.0), Color(0.2, 0.34, 0.15))
		_foliage_blob(pos + Vector3(1.2, height - 1.7, 0.6), Vector3(4.0, 3.0, 3.7), Color(0.3, 0.42, 0.18))

	for i in range(72):
		var side := -1.0 if i % 2 == 0 else 1.0
		var pos := Vector3(side * rng.randf_range(7.8, 10.2), 0.25, rng.randf_range(-36.0, 36.0))
		# Keep the workshop approach and east-west quest route unobstructed.
		if absf(pos.z - 8.0) < 6.5:
			continue
		_foliage_blob(pos, Vector3(rng.randf_range(0.9, 2.0), rng.randf_range(0.5, 1.1), rng.randf_range(0.8, 1.8)), Color(0.27, 0.38, 0.16))

	# Climbing vegetation on exterior facades, avoiding the playable shelter.
	for facade in [Vector3(-20, 0, -7.85), Vector3(20, 0, -10.85), Vector3(22, 0, 15.8), Vector3(-23, 0, 20.3)]:
		var tall := facade.z < 0.0
		for column in range(5):
			var x := facade.x - 6.0 + float(column) * 3.0
			var height := rng.randf_range(4.0, 8.0) if tall else rng.randf_range(1.5, 3.4)
			_visual_box(Vector3(x, height / 2.0, facade.z), Vector3(0.14, height, 0.12), Color(0.25, 0.3, 0.13))
			for segment in range(4):
				_foliage_blob(Vector3(x + rng.randf_range(-0.4, 0.4), height * float(segment + 1) / 4.0, facade.z), Vector3(1.4, 1.2, 0.9), Color(0.24, 0.38, 0.16))

	# A visible, static edge of greenery outside the workshop entrance.
	for i in range(8):
		var x := -29.0 + float(i) * 2.0
		if x > -25.0 and x < -19.0:
			continue
		_foliage_blob(Vector3(x, 0.25, 1.4), Vector3(1.5, 0.6, 1.4), Color(0.28, 0.39, 0.18))

func _unhandled_input(event: InputEvent) -> void:
 if player and player.crafting_visible:
  if event is InputEventKey and event.pressed and not event.echo:
   if event.physical_keycode == KEY_1: _craft_recipe("crowbar")
   elif event.physical_keycode == KEY_2: _craft_recipe("respirator")
   elif event.physical_keycode == KEY_3: _craft_recipe("water_filter")
 if event.is_action_pressed("quick_save"): _save_game()
 if event.is_action_pressed("quick_load"): _load_game()

func _save_game() -> void:
 var data={"player":player.get_save_state(),"generator_repaired":generator.repaired,"generator_on":generator.is_on,"journal_order":journal_order,"journal_entries":journal_entries,"ecosystem_pressure":ecosystem_pressure,"lab_entered":lab_entered,"greenhouse_sample_found":greenhouse_sample_found}
 var f=FileAccess.open(SAVE_PATH,FileAccess.WRITE)
 if f: f.store_string(JSON.stringify(data)); _on_message_requested("Игра сохранена")

func _load_game() -> void:
 if not FileAccess.file_exists(SAVE_PATH): _on_message_requested("Сохранение не найдено"); return
 var data=JSON.parse_string(FileAccess.get_file_as_string(SAVE_PATH))
 if not data is Dictionary: _on_message_requested("Ошибка сохранения"); return
 player.apply_save_state(data.get("player",{})); generator.repaired=bool(data.get("generator_repaired",false)); generator.is_on=bool(data.get("generator_on",false))
 journal_order.clear()
 for id in data.get("journal_order",[]): journal_order.append(str(id))
 journal_entries=data.get("journal_entries",{}).duplicate(true); ecosystem_pressure=float(data.get("ecosystem_pressure",0.0)); lab_entered=bool(data.get("lab_entered",false)); greenhouse_sample_found=bool(data.get("greenhouse_sample_found",false)); _update_ecosystem_label(); _update_reactive_ecosystem(); _on_power_state_changed(generator.is_on); _refresh_journal(); _update_objective(); _on_message_requested("Сохранение загружено")

func _refresh_journal() -> void:
 var lines: Array[String]=["[b]ПОЛЕВОЙ ЖУРНАЛ[/b]  —  [J] или [Esc] закрыть",""]
 for i in range(journal_order.size()-1,-1,-1):
  var id=journal_order[i]
  if journal_entries.has(id):
   var entry: Dictionary=journal_entries[id]; lines.append("[b]"+str(entry.get("title","Запись"))+"[/b]"); lines.append(str(entry.get("body",""))); lines.append("")
 journal_text.text="\n".join(lines)

func _build_spore_zones() -> void:
 _create_spore_zone(Vector3(25,1.4,-2),Vector3(9,2.8,9),"Споровая низина")
 _create_spore_zone(Vector3(-5,1.4,34),Vector3(7,2.8,8),"Заросший двор")

func _create_spore_zone(pos: Vector3,size: Vector3,zone_name: String) -> void:
 var area:=Area3D.new(); area.name=zone_name; area.position=pos; area.collision_layer=0; area.collision_mask=4; area.set_script(SPORE_ZONE_SCRIPT)
 var shape:=BoxShape3D.new(); shape.size=size; var collision:=CollisionShape3D.new(); collision.shape=shape; area.add_child(collision); add_child(area)
 for i in range(10):
  var a:=TAU*float(i)/10.0; _foliage_blob(pos+Vector3(cos(a)*size.x*0.35,0.35,sin(a)*size.z*0.35),Vector3(1.2,0.7,1.2),Color(0.36,0.42,0.12))


func _build_salvage_loop() -> void:
 var locker = _create_interactable_box("ToolLocker", Vector3(-19.0,0.7,7.3), Vector3(1.0,1.4,0.8), Color(0.24,0.28,0.25), CONTAINER_SCRIPT)
 locker.display_name = "Шкаф с инструментами"
 locker.loot = [{"id":"scrap","name":"Металлолом","amount":1},{"id":"bolts","name":"Крепёж","amount":2}]
 _create_salvage(Vector3(4.8,0.55,-19.0), "Старый электрощит", [{"id":"wire","name":"Медный провод","amount":3},{"id":"electronics","name":"Электронные компоненты","amount":2},{"id":"scrap","name":"Металлолом","amount":2}])
 _create_salvage(Vector3(13.0,0.55,10.5), "Сломанный торговый автомат", [{"id":"plastic","name":"Пластик","amount":2},{"id":"scrap","name":"Металлолом","amount":3},{"id":"chemicals","name":"Химикаты","amount":1}])
 _create_salvage(Vector3(-12.0,0.55,31.0), "Старая мебель", [{"id":"cloth","name":"Ткань","amount":3},{"id":"scrap","name":"Металлолом","amount":1}])
 _create_pickup(Vector3(8.0,0.4,24.0), "charcoal", "Древесный уголь", 2, Color(0.12,0.12,0.1))

func _create_salvage(pos: Vector3, object_name: String, drops: Array[Dictionary]) -> void:
 var obj = _create_interactable_box("Salvage_"+object_name, pos, Vector3(1.2,1.1,1.0), Color(0.22,0.23,0.20), SALVAGE_SCRIPT)
 obj.display_name = object_name
 obj.salvage = drops

func _craft_recipe(recipe_id: String) -> void:
 var recipes := {
  "crowbar":{"name":"Монтировка","cost":{"scrap":2,"bolts":2},"out":"crowbar"},
  "respirator":{"name":"Самодельный респиратор","cost":{"cloth":2,"plastic":1,"chemicals":1},"out":"respirator"},
  "water_filter":{"name":"Фильтр для воды","cost":{"plastic":2,"cloth":1,"charcoal":2},"out":"water_filter"}
 }
 var recipe: Dictionary = recipes[recipe_id]
 if player.has_item(recipe["out"]): _on_message_requested("Уже изготовлено: "+recipe["name"]); return
 if not player.remove_items(recipe["cost"]): _on_message_requested("Не хватает материалов для: "+recipe["name"]); return
 player.add_item(recipe["out"], recipe["name"], 1)
 ecosystem_pressure += 4.0 if recipe_id == "crowbar" else 2.0
 _update_ecosystem_label()
 _update_reactive_ecosystem()

func _update_ecosystem_label() -> void:
 if not ecosystem_label: return
 var state := "спокойна"
 if ecosystem_pressure >= 20.0: state = "возбуждена"
 elif ecosystem_pressure >= 8.0: state = "насторожена"
 ecosystem_label.text = "ЭКОСИСТЕМА: %s   /   воздействие %.0f" % [state.to_upper(), ecosystem_pressure]


# A1.4: first systemic response from the Green Limit ecosystem.
func _build_riverdale_extension() -> void:
 # A graybox extension toward the ecology lab. Visual references live in docs/visual_reference.
 _create_box_static("LabWing", Vector3(33,3.2,-24), Vector3(12,6.4,15), Color(0.27,0.29,0.25))
 _create_box_static("LabGreenhouse", Vector3(24,1.8,-32), Vector3(9,3.6,8), Color(0.31,0.39,0.32))
 _create_box_static("LabService", Vector3(33,1.4,-12), Vector3(10,2.8,6), Color(0.23,0.25,0.23))
 _sign(Vector3(33,4.5,-16.55), "GREENBELT ECOLOGY LAB", 42)
 _sign(Vector3(24,3.0,-27.95), "GREENHOUSE", 36)
 # Traversal landmarks matching the approved Riverdale direction.
 _create_box_static("BusShell", Vector3(-2.8,1.25,7.0), Vector3(2.5,2.5,8.5), Color(0.42,0.34,0.10))
 _sign(Vector3(-2.8,2.4,2.72), "SCHOOL BUS", 28)
 _create_box_static("MarketAnnex", Vector3(31,1.6,27), Vector3(10,3.2,7), Color(0.28,0.27,0.23))
 _sign(Vector3(31,2.7,23.45), "PINE RIDGE MARKET", 34)

func _build_reactive_ecosystem() -> void:
 for data in [
  [Vector3(11,0,-4),8.0,20.0],
  [Vector3(27,0,-18),8.0,16.0],
  [Vector3(-7,0,31),12.0,22.0]
 ]:
  var growth := Node3D.new()
  growth.name = "ReactiveGrowth"
  growth.position = data[0]
  growth.set_script(REACTIVE_GROWTH_SCRIPT)
  growth.activation_pressure = data[1]
  growth.hostile_pressure = data[2]
  add_child(growth)
  growth.set_player(player)
  reactive_growths.append(growth)
 _update_reactive_ecosystem()

func _update_reactive_ecosystem() -> void:
 for growth in reactive_growths:
  if is_instance_valid(growth) and growth.has_method("set_pressure"):
   growth.set_pressure(ecosystem_pressure)


# A1.5: stealth/noise, first mobile threat, and playable Greenbelt entry.
func _build_a15_threat_and_lab() -> void:
 var threat := CharacterBody3D.new()
 threat.name = "RootStalker_01"
 threat.position = Vector3(15,0.2,-28)
 threat.collision_layer = 1
 threat.collision_mask = 1
 threat.set_script(CREATURE_THREAT_SCRIPT)
 add_child(threat)
 threat.set_player(player)
 living_threats.append(threat)
 # Exterior lab door teleports into a separated prototype interior, avoiding the solid graybox shell.
 var door = _create_interactable_box("LabEntry", Vector3(33,1.2,-16.3), Vector3(2.2,2.4,0.35), Color(0.18,0.27,0.20), LAB_DOOR_SCRIPT)
 door.display_name = "Войти в Greenbelt Ecology Lab"
 door.destination = Vector3(53,0.3,-24)
 door.world = self
 # Prototype lab interior.
 _create_box_static("LabInteriorFloor",Vector3(53,-0.1,-24),Vector3(12,0.2,12),Color(0.20,0.22,0.19))
 _create_box_static("LabInteriorNorth",Vector3(53,2.2,-30),Vector3(12,4.4,0.25),Color(0.25,0.27,0.24))
 _create_box_static("LabInteriorSouth",Vector3(53,2.2,-18),Vector3(12,4.4,0.25),Color(0.25,0.27,0.24))
 _create_box_static("LabInteriorEast",Vector3(59,2.2,-24),Vector3(0.25,4.4,12),Color(0.25,0.27,0.24))
 _create_box_static("LabInteriorWest",Vector3(47,2.2,-24),Vector3(0.25,4.4,12),Color(0.25,0.27,0.24))
 _create_note(Vector3(53,0.35,-25.5),"lab_first_log","Журнал лаборатории")
 var exit_door = _create_interactable_box("LabExit",Vector3(53,1.2,-18.25),Vector3(2.0,2.4,0.3),Color(0.20,0.25,0.21),LAB_DOOR_SCRIPT)
 exit_door.display_name="Выйти из лаборатории"; exit_door.destination=Vector3(33,0.3,-15.2); exit_door.requires_crowbar=false; exit_door.requires_archive=false; exit_door.world=self
 _sign(Vector3(53,3.2,-29.82),"GREENBELT / FIELD UNIT 04",30)

func has_story_entry(id: String) -> bool:
 return journal_entries.has(id)

func on_lab_entered() -> void:
 if not lab_entered:
  lab_entered=true
  ecosystem_pressure += 6.0
  _update_ecosystem_label(); _update_reactive_ecosystem()
  _on_message_requested("Внутри слишком чисто. Но из вентиляции слышен шорох.")
 _update_objective()


# A1.6: expanded lab, greenhouse B, decoy noise, death/respawn, story clue.
func _build_a16_lab_extension() -> void:
 # Two connected prototype rooms east of Field Unit 04.
 _create_box_static("LabCorridorFloor",Vector3(64,-0.1,-24),Vector3(10,0.2,4),Color(0.19,0.21,0.18))
 _create_box_static("GreenhouseBFloor",Vector3(73,-0.1,-24),Vector3(8,0.2,12),Color(0.18,0.22,0.17))
 _create_box_static("GreenhouseBNorth",Vector3(73,2.2,-30),Vector3(8,4.4,0.25),Color(0.24,0.29,0.23))
 _create_box_static("GreenhouseBSouth",Vector3(73,2.2,-18),Vector3(8,4.4,0.25),Color(0.24,0.29,0.23))
 _create_box_static("GreenhouseBEast",Vector3(77,2.2,-24),Vector3(0.25,4.4,12),Color(0.24,0.29,0.23))
 # Lab benches create readable cover and lanes.
 for z in [-27.0,-24.0,-21.0]:
  _create_box_static("GreenhouseBench",Vector3(72.7,0.55,z),Vector3(4.8,1.1,1.0),Color(0.24,0.26,0.20))
  for x in [71.2,72.7,74.2]: _foliage_blob(Vector3(x,1.1,z),Vector3(0.7,0.8,0.7),Color(0.28,0.42,0.18))
 _sign(Vector3(76.82,3.1,-24),"GREENHOUSE B",28)
 _create_note(Vector3(74.5,0.35,-27.0),"greenhouse_log","Планшет из теплицы B")
 _create_pickup(Vector3(75.0,0.4,-21.0),"sample_zero","Образец субстрата ZERO",1,Color(0.56,0.72,0.42))
 # A reusable noise lure in the corridor.
 var decoy = _create_interactable_box("NoiseDecoy",Vector3(64,0.45,-22.8),Vector3(0.7,0.9,0.7),Color(0.45,0.31,0.15),NOISE_DECOY_SCRIPT)
 decoy.display_name="Аварийный зуммер"; decoy.world=self
 # A second stalker makes the lab a stealth space rather than a safe lore room.
 var threat := CharacterBody3D.new(); threat.name="RootStalker_Lab"; threat.position=Vector3(69,0.2,-26)
 threat.collision_layer=1; threat.collision_mask=1; threat.set_script(CREATURE_THREAT_SCRIPT); add_child(threat); threat.set_player(player); living_threats.append(threat)

func emit_noise_at(pos: Vector3, strength: float = 1.0) -> void:
 for threat in living_threats:
  if is_instance_valid(threat) and threat.has_method("hear_noise"):
   threat.hear_noise(pos,strength)

func on_greenhouse_sample_collected() -> void:
 if greenhouse_sample_found: return
 greenhouse_sample_found=true
 ecosystem_pressure += 5.0
 _add_story_entry("zero_sample")
 _update_ecosystem_label(); _update_reactive_ecosystem(); _update_objective()
 _on_message_requested("Образец ZERO совпадает с материалом под фундаментом мастерской. Кто-то подготовил эту границу заранее.")

func _on_player_died() -> void:
 _on_message_requested("Ты потерял сознание. Мастерская снова стала точкой возврата.")
 await get_tree().create_timer(1.0).timeout
 player.respawn_at(Vector3(-22,0.25,6.2))
 ecosystem_pressure += 2.0
 _update_ecosystem_label(); _update_reactive_ecosystem()
