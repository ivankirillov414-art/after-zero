extends StaticBody3D

signal power_state_changed(is_on: bool)
signal repair_completed

@export var display_name := "Старый генератор"
var is_on := false
var repaired := false

func get_interaction_text() -> String:
	if is_on:
		return "[E] Заглушить генератор"
	if repaired:
		return "[E] Запустить генератор"
	return "[E] Осмотреть генератор"

func interact(actor) -> void:
	if is_on:
		is_on = false
		power_state_changed.emit(false)
		actor.message_requested.emit("Генератор остановлен")
		return

	if repaired:
		is_on = true
		power_state_changed.emit(true)
		actor.message_requested.emit("Генератор запущен — в убежище появился свет")
		return

	var missing: Array[String] = []
	if !actor.inventory.has("spark_plug"):
		missing.append("свеча зажигания")
	if !actor.inventory.has("fuel"):
		missing.append("канистра топлива")
	if !actor.inventory.has("carburetor"):
		missing.append("карбюратор")

	if !missing.is_empty():
		actor.message_requested.emit("Для ремонта нужны: %s" % ", ".join(missing))
		return

	actor.consume_item("spark_plug")
	actor.consume_item("fuel")
	actor.consume_item("carburetor")
	repaired = true
	repair_completed.emit()
	actor.message_requested.emit("Генератор отремонтирован. Нажми E ещё раз, чтобы запустить.")
