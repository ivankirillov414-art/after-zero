extends CharacterBody3D

signal inventory_changed(items: Dictionary)
signal stats_changed(stats: Dictionary)
signal interaction_changed(text: String)
signal message_requested(text: String)
signal note_found(note_id: String, title: String, body: String)
signal died

@export var walk_speed := 4.2
@export var sprint_speed := 7.2
@export var crouch_speed := 2.2
@export var jump_velocity := 4.8
@export var mouse_sensitivity := 0.0022
@export var max_stamina := 100.0

@onready var head: Node3D = $Head
@onready var camera: Camera3D = $Head/Camera3D
@onready var interact_ray: RayCast3D = $Head/Camera3D/InteractRay
@onready var flashlight: SpotLight3D = $Head/Camera3D/Flashlight
@onready var collision_shape: CollisionShape3D = $CollisionShape3D

var gravity := 9.8
var stamina := 100.0
var health := 100.0
var hunger := 100.0
var thirst := 100.0
var inventory: Dictionary = {}
var inventory_visible := false
var journal_visible := false
var crafting_visible := false
var is_crouching := false
var last_interaction_text := ""
var current_noise := 0.15
var death_emitted := false

func _ready() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	gravity = float(ProjectSettings.get_setting("physics/3d/default_gravity", 9.8))
	interact_ray.add_exception(self)
	_emit_stats()
	inventory_changed.emit(inventory.duplicate())

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * mouse_sensitivity)
		head.rotate_x(-event.relative.y * mouse_sensitivity)
		head.rotation.x = clamp(head.rotation.x, deg_to_rad(-88), deg_to_rad(88))

	if event.is_action_pressed("inventory"):
		inventory_visible = !inventory_visible
		journal_visible = false
		_sync_mouse_mode()

	if event.is_action_pressed("journal"):
		journal_visible = !journal_visible
		inventory_visible = false
		_sync_mouse_mode()

	if event.is_action_pressed("crafting"):
		toggle_crafting()

	if event.is_action_pressed("flashlight"):
		flashlight.visible = !flashlight.visible

	if event.is_action_pressed("use_water") and _gameplay_input_enabled(): use_consumable("water", "Вода", 0.0, 38.0, 0.0)
	if event.is_action_pressed("use_food") and _gameplay_input_enabled(): use_consumable("food", "Еда", 34.0, 0.0, 0.0)
	if event.is_action_pressed("use_medkit") and _gameplay_input_enabled(): use_consumable("medkit", "Аптечка", 0.0, 0.0, 45.0)

	if event.is_action_pressed("interact") and _gameplay_input_enabled():
		_try_interact()

	if event.is_action_pressed("ui_cancel"):
		if inventory_visible or journal_visible or crafting_visible:
			inventory_visible = false
			journal_visible = false
			crafting_visible = false
			Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
		else:
			Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE if Input.mouse_mode == Input.MOUSE_MODE_CAPTURED else Input.MOUSE_MODE_CAPTURED)

func _physics_process(delta: float) -> void:
	if !is_on_floor():
		velocity.y -= gravity * delta

	var input_enabled := _gameplay_input_enabled()
	is_crouching = input_enabled and Input.is_action_pressed("crouch")
	var input_dir := Input.get_vector("move_left", "move_right", "move_forward", "move_back") if input_enabled else Vector2.ZERO
	var direction := (transform.basis * Vector3(input_dir.x, 0, input_dir.y)).normalized()

	var moving := direction.length() > 0.01
	var sprinting := Input.is_action_pressed("sprint") and moving and !is_crouching and stamina > 0.5
	var speed := crouch_speed if is_crouching else (sprint_speed if sprinting else walk_speed)

	if direction:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed * 8.0 * delta)
		velocity.z = move_toward(velocity.z, 0, speed * 8.0 * delta)

	if Input.is_action_just_pressed("jump") and is_on_floor() and !is_crouching and input_enabled:
		velocity.y = jump_velocity

	if sprinting:
		stamina = max(0.0, stamina - 18.0 * delta)
	else:
		stamina = min(max_stamina, stamina + 12.0 * delta)

	# Prototype survival drain. Intentionally slow enough for testing.
	hunger = max(0.0, hunger - 0.11 * delta)
	thirst = max(0.0, thirst - 0.17 * delta)
	if hunger <= 0.0 or thirst <= 0.0:
		health = max(0.0, health - 1.0 * delta)

	var target_head_y := 1.15 if is_crouching else 1.62
	head.position.y = lerp(head.position.y, target_head_y, 10.0 * delta)

	# A1.5 noise model: crouching is quiet, walking is audible, sprinting is loud.
	if moving:
		current_noise = 0.28 if is_crouching else (1.0 if sprinting else 0.58)
	else:
		current_noise = 0.12
	if flashlight.visible: current_noise += 0.04
	move_and_slide()
	_update_interaction_prompt()
	_emit_stats()
	if health <= 0.0 and not death_emitted:
		death_emitted = true
		died.emit()

func add_item(item_id: String, display_name: String, amount: int = 1) -> void:
	if !inventory.has(item_id):
		inventory[item_id] = {"name": display_name, "amount": 0}
	inventory[item_id]["amount"] += amount
	inventory_changed.emit(inventory.duplicate(true))
	message_requested.emit("Получено: %s x%d" % [display_name, amount])
	if item_id == "sample_zero" and get_parent().has_method("on_greenhouse_sample_collected"):
		get_parent().on_greenhouse_sample_collected()


func has_item(item_id: String, amount: int = 1) -> bool:
	return inventory.has(item_id) and int(inventory[item_id].get("amount", 0)) >= amount

func remove_items(costs: Dictionary) -> bool:
	for item_id in costs:
		if not has_item(str(item_id), int(costs[item_id])):
			return false
	for item_id in costs:
		var amount := int(costs[item_id])
		inventory[item_id]["amount"] -= amount
		if int(inventory[item_id]["amount"]) <= 0:
			inventory.erase(item_id)
	inventory_changed.emit(inventory.duplicate(true))
	return true

func toggle_crafting() -> void:
	crafting_visible = not crafting_visible
	inventory_visible = false
	journal_visible = false
	_sync_mouse_mode()

func consume_item(item_id: String) -> bool:
	if !inventory.has(item_id) or int(inventory[item_id]["amount"]) <= 0:
		return false
	inventory[item_id]["amount"] -= 1
	if int(inventory[item_id]["amount"]) <= 0:
		inventory.erase(item_id)
	inventory_changed.emit(inventory.duplicate(true))
	return true

func restore_survival(food: float, water: float, hp: float = 0.0) -> void:
	hunger = clamp(hunger + food, 0.0, 100.0)
	thirst = clamp(thirst + water, 0.0, 100.0)
	health = clamp(health + hp, 0.0, 100.0)
	_emit_stats()

func _try_interact() -> void:
	if !interact_ray.is_colliding():
		return
	var target = interact_ray.get_collider()
	if target and target.has_method("interact"):
		target.interact(self)

func _update_interaction_prompt() -> void:
	var text := ""
	if _gameplay_input_enabled() and interact_ray.is_colliding():
		var target = interact_ray.get_collider()
		if target and target.has_method("get_interaction_text"):
			text = str(target.get_interaction_text())
	if text != last_interaction_text:
		last_interaction_text = text
		interaction_changed.emit(text)

func _emit_stats() -> void:
	stats_changed.emit({
		"health": health,
		"hunger": hunger,
		"thirst": thirst,
		"stamina": stamina
	})

func _gameplay_input_enabled() -> bool:
	return not inventory_visible and not journal_visible and not crafting_visible and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED

func _sync_mouse_mode() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE if inventory_visible or journal_visible or crafting_visible else Input.MOUSE_MODE_CAPTURED)

func read_note(note_id: String, title: String, body: String) -> void:
	note_found.emit(note_id, title, body)
	inventory_visible = false
	journal_visible = true
	_sync_mouse_mode()

func use_consumable(item_id: String, display_name: String, food: float, water: float, hp: float) -> void:
 if consume_item(item_id):
  restore_survival(food, water, hp)
  message_requested.emit("Использовано: " + display_name)
 else: message_requested.emit("Нет предмета: " + display_name)

func apply_environment_damage(amount: float, warning: String = "") -> void:
 health = max(0.0, health - amount)
 if warning != "": message_requested.emit(warning)
 _emit_stats()

func get_save_state() -> Dictionary:
 return {"position":[position.x,position.y,position.z],"health":health,"hunger":hunger,"thirst":thirst,"stamina":stamina,"inventory":inventory.duplicate(true)}

func apply_save_state(data: Dictionary) -> void:
 var p = data.get("position", [-22.0,0.25,6.2])
 position = Vector3(float(p[0]),float(p[1]),float(p[2]))
 health=float(data.get("health",100.0)); hunger=float(data.get("hunger",100.0)); thirst=float(data.get("thirst",100.0)); stamina=float(data.get("stamina",100.0))
 inventory=data.get("inventory",{}).duplicate(true)
 inventory_changed.emit(inventory.duplicate(true)); _emit_stats()

func get_noise_level() -> float:
 return current_noise


func respawn_at(spawn_position: Vector3) -> void:
 global_position = spawn_position
 velocity = Vector3.ZERO
 health = 70.0
 hunger = maxf(hunger, 45.0)
 thirst = maxf(thirst, 45.0)
 stamina = max_stamina
 death_emitted = false
 inventory_visible=false; journal_visible=false; crafting_visible=false
 Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
 _emit_stats()
